const botao = document.getElementById("botaoReceberFilmes");
const input = document.getElementById("caixa-pesquisar-filmes");
const resultadoContainer = document.getElementById("resultado-pesquisa-filme");
const detalheContainer = document.getElementById("detalhe-filme");

//Recebendo a nossa API através da constante receberFilmes.

// async function receberFilmes(nomeFilme) {
//   // const urlAPI = async (`https://www.omdbapi.com/?apikey=3811fe&s=${nomeFilme}`) async deve ser usado apenas para trabalhar-se com funções
//   const urlAPI =  (`https://www.omdbapi.com/?apikey=3811fe&s=${nomeFilme}`)

//   try{
//     const response = await fetch(urlAPI)
//     if (!response.ok) {
//       throw new Error(`Resposta do Servidor: ${response.status}`)
//     }
//     const dadosRecebidos = await response.json();
//     console.log(dadosRecebidos);

//   } catch(error) {

//     console.error(error);
//   }
// }

// botaoReceberFilmes.addEventListener("click", () => {  //Recebendo as informações de receberFilmes quando clicado, através da pesquisarFilmes.value, que seria o valor do elemento pesquisado, ai com isso a nossa function é declarada exibindo o valor
//   const filme = pesquisarFilmes.value;
//   receberFilmes(filme)
// }

// );

const API_KEY = "3811fe";

async function receberFilmes(nomeFilme){
    // const urlAPI = async (`https://www.omdbapi.com/?apikey=3811fe&s=${nomeFilme}`) async deve ser usado apenas para trabalhar-se com funções
     //Recebendo as informações de receberFilmes quando clicado, através da pesquisarFilmes.value, que seria o valor do elemento pesquisado, ai com isso a nossa function é declarada exibindo o valor
    const url = `https://www.omdbapi.com/?apikey=${API_KEY}&s=${nomeFilme}`;

    try{
        const response = await fetch(url);
        const data = await response.json();

        if(data.Response === "True"){
            mostrarListaDeFilmes(data.Search);
        } else {
            resultadoContainer.innerHTML = "<p>Filme não encontrado</p>";
        }

    }catch(error){
        console.error(error);
    }
}

function mostrarListaDeFilmes(filmes){

    resultadoContainer.innerHTML = "";

    filmes.forEach(filme => {

        const poster = filme.Poster !== "N/A"
            ? filme.Poster
            : "https://via.placeholder.com/300x450?text=No+Image";

        const card = document.createElement("div");
        card.classList.add("movie-card");
        card.dataset.id = filme.imdbID;

        card.innerHTML = `
            <img src="${poster}" alt="${filme.Title}">
            <h3>${filme.Title}</h3>
            <p>${filme.Year}</p>
        `;

        resultadoContainer.appendChild(card);
    });
}

resultadoContainer.addEventListener("click", async (event)=>{

    const card = event.target.closest(".movie-card");
    if(!card) return;

    const id = card.dataset.id;

    const response = await fetch(`https://www.omdbapi.com/?apikey=${API_KEY}&i=${id}&plot=full`);
    const data = await response.json();

    mostrarDescricaoFilmes(data);
});

function mostrarDescricaoFilmes(detalhes){


    //Através da function mostrarDescricaoFilmes estamos passando o parâmetro detalhes que recebe detalhes do próprio parâmetro dentro dos parênteses, onde nós adicionamos os detalhes através de .NomeDoElemento na API
    const poster = detalhes.Poster !== "N/A"
        ? detalhes.Poster
        : "https://via.placeholder.com/300x450?text=No+Image"; //não temos nenhuma imagem


        //Detalhe container nos permite adicionar os elementos de html 
    detalheContainer.innerHTML = `
        <div class="poster-filme">
            <img src="${poster}">
        </div>
        <div class="descricao-filme">
            <h3>${detalhes.Title}</h3>
            <p><strong>Ano:</strong> ${detalhes.Year}</p>
            <p><strong>Classificação:</strong> ${detalhes.Rated}</p>
            <p><strong>Lançamento:</strong> ${detalhes.Released}</p>
            <p><strong>Genero:</strong> ${detalhes.Genre}</p>
            <p><strong>Escritor:</strong> ${detalhes.Writer}</p>
            <p><strong>Atores:</strong> ${detalhes.Actors}</p>
            <p><strong>Resumo:</strong> ${detalhes.Plot}</p>
            <p><strong>Língua:</strong> ${detalhes.Language}</p>
            <p><strong>Prêmios:</strong> ${detalhes.Awards}</p>
        </div>
    `;
}

botao.addEventListener("click", ()=>{
    const valor = input.value.trim();
    if(valor.length > 0){
        receberFilmes(valor);
    }
});